//#pragma GCC optimize(3)
#include<bits/stdc++.h>
#define SZ(x) ((int)x.size())
#define uni(x) sort(all(x)),x.resize(unique(all(x))-x.begin());
#define GETPOS(c,x) (lower_bound(all(c),x)-c.begin())
#define lown1(x,val) low(in(x),val)-x
#define lowm1(x,val) low(im(x),val)-x
#define low1(x,nums,val) low(x+1,x+nums+1,val)-x
#define mst(x,val) memset((x),val,sizeof((x)))
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define far(i,V) for(auto &i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define lcm(a,b) ((a)*(b))/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) ((x)&(-x))
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) (((x)<0)?(x)%mo_num+mo_num:(x)%mo_num)
#define vc vector
#define vct vector<int>
#define SET set<int>
#define dq deque<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define Umap unordered_map<int,int>
#define P pair<int,int>
#define mk make_tuple
#define eps 1e-6
//Remember cancel"#define endl '\n'" in interactive questions or use "<<flush"
#define endl '\n'
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
//#define yn(key) out(key?"Yes":"No")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define ik(i,k) i+1,i+1+k
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
#define db double
#define ll long long
#define got(container,num) get<num-1>(container)
//#define int long long
#define print(a,n) fun(i)cout<<a[i]<<(i!=n?' ':endl);
#define outcase(x) cout<<"Case #"<<(++case_of_T)<<": "<<(x)<<endl;
#define ptcase(x) printf("Case #%d: %d\n",++case_of_T,x);
#define plcase(x) printf("Case #%lld: %lld\n",++case_of_T,x);
using namespace std;
//Remember to cancel the line below and declare INT=INT_MAX/2; when you want to change long to int
//const int INF=LLONG_MAX/4,SINF=0x3f3f3f3f,Lim=1<<20,MINF=LLONG_MAX;
const int INF=INT_MAX/4,SINF=0x3f;
// use C:printf("%.16f", x);  ->  printf("%.10f", x); can accelerate the program
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//down up left right
const int maxn=1e6+10;
int mo_num=1e9+7;
//const int mo_num=998244353;
int n,m,t,a[maxn],case_of_T;
ll ans;
// �ɳ��ز��鼯ģ��
struct DSU {
    stack<pair<int,int> >stk;
    int p[maxn],siz[maxn];
    void init(int x) {
        fu(i,1,x+1){
            p[i] = i;
            siz[i] = 1;
        }
    }
    int Find(int x) {
        return x == p[x] ? x : Find(p[x]);
    }
    bool merge(int x,int y) {
        int rx = Find(x),ry = Find(y);
        if(rx == ry) return false;
        if(siz[rx] > siz[ry]) swap(rx,ry);
        p[rx] = ry;
        siz[ry] += siz[rx];
        stk.push({rx,ry});
        return true;
    }
    void undo() {
        pair<int,int>now = stk.top();
        p[now.first] = now.first;
        siz[now.second] -= siz[now.first];
        stk.pop();
    }
}dsu;
map<P,int>vis;
vc<P> Que[maxn],one[maxn];
P to[maxn];
int cnt,To[maxn],cant[maxn];
Umap E;
vct have;
void solve()
{
    int k;
    cin>>n>>m>>k;
    dsu.init(n);
    fun(i)cin>>a[i];
    int Cnt=0;
    fum(i)
    {
        int x,y;
        cin>>x>>y;
        if(!vis[{a[x],a[y]}]) {
            if(a[x]!=a[y])vis[{a[x], a[y]}] = vis[{a[y], a[x]}] = ++cnt,to[cnt]={a[x],a[y]};
            else vis[{a[x],a[y]}]=++Cnt,To[Cnt]=a[x];
        }
        if(a[x]!=a[y])Que[vis[{a[x],a[y]}]].pb({x,y});
        else one[vis[{a[x],a[y]}]].pb({x,y});
    }
    fu(i,1,Cnt)
    {
        //���滷ģ��
        fa(j,one[i])
        {
            int Fz=dsu.Find(j.fi),Fy=dsu.Find(j.se);
            if(Fz==Fy){k--;cant[To[i]]=1;break;}
            if(!E[Fz])E[Fz]=Fy; else dsu.merge(dsu.p[Fy],dsu.Find(E[Fz]));
            if(!E[Fy])E[Fy]=Fz; else dsu.merge(dsu.p[Fz],dsu.Find(E[Fy]));
        }
    }
    ans=1LL*k*(k-1)/2;
    fu(i,1,cnt)
    {
        if(cant[to[i].fi] or cant[to[i].se])continue;
        int num=0;
        fa(j,Que[i])
        {
            int Fz=dsu.Find(j.fi),Fy=dsu.Find(j.se);
            if(Fz==Fy){ans--;break;}
            if(!E[Fz])E[Fz]=Fy,have.pb(Fz); else num+=dsu.merge(Fy,E[Fz]);//����������
            if(!E[Fy])E[Fy]=Fz,have.pb(Fy); else num+=dsu.merge(Fz,E[Fy]);
        }
        fu(j,1,num)dsu.undo();
        while(!have.empty()){E[have.back()]=0;have.ppb();}
    }
    out(ans)
    return ;
}
main()
{
    IOS
    int T=1;
    //cin>>T;
    while(T--)solve();
    return 0;
}
