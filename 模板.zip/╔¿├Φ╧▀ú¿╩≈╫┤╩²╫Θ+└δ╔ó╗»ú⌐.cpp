#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int INF=LLONG_MAX-1e10;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=2e5+10;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
int Ans[maxn],havey[maxn];
void update(int pos,int val,int *f){ for(int i=pos;i<=n;i+=lowbit(i)) f[i] += val; }
int getsum(int pos,int *f){ int num = 0;for(int i=pos;i;i-=lowbit(i))num += f[i];return num; }
struct shuxian{
    int x,y,val;
    bool operator<(const shuxian&a)const {
        return y<a.y;
    }
}shu[maxn<<1];
struct hengxian{
    int z,y,h;
    bool operator<(const hengxian&a)const {
        return h<a.h;
    }
}heng[maxn<<1];
int ps[maxn],ph[maxn],fs,fh;
int Find_y_s(int x)
{
    int num=lower_bound(ps,ps+1+fs,x)-ps;
    return num;
}
int Find_x_h(int x)
{
    int num=lower_bound(ph,ph+1+fh,x)-ph;
    return num;
}
main()
{
    IOS
    cin>>n>>m;
    fun(i)
    {
        int x1,x2,y1,y2;
        cin>>x1>>y1>>x2>>y2;
        if(x1==x2)//����,��¼���µ�(x,y,1)
        {
            shu[++fs]={x1,y1,1};
            ps[fs]=x1;
            shu[++fs]={x1,y2+1,-1};
            ps[fs]=x2;
        }else{
            heng[++fh]={x1,x2,y1};
            ph[fh]=y1;
        }
    }
    int ffh=fh,ffs=fs;
    sort(shu+1,shu+fs+1);
    sort(ps+1,ps+fs+1);
    sort(heng+1,heng+fh+1);
    sort(ph+1,ph+fh+1);
    fs=unique(ps+1,ps+fs+1)-ps-1;
    fh=unique(ph+1,ph+fh+1)-ph-1;
    int numy=1;
    fu(i,1,ffh)
    {
        int z=heng[i].z,y=heng[i].y;
        while (numy <= ffs && shu[numy].y <= heng[i].h) {
            int xx = upper_bound(ps, ps + 1 + fs, shu[numy].x) - ps-1;
            update(xx, shu[numy].val, havey);
            numy++;
        }
        int yy=upper_bound(ps,ps+1+fs,y)-ps-1;
        int zz=upper_bound(ps,ps+1+fs,z-1)-ps-1;
        int q=Find_x_h(heng[i].h),w=getsum(yy,havey),e=getsum(zz,havey);
        update(q,w-e,Ans);
    }

    fum(i)
    {
        int x,s;
        cin>>x>>s;
        //Find_x_h()�����ҵ�������Ϊsʱ��Ӧ����״�����е��±꣨ǰ����
        int ss=Find_x_h(s+1)-1,xx=Find_x_h(x)-1;
        int S=getsum(ss,Ans),X=getsum(xx,Ans);
        out(S-X)
    }
    return 0;
}
