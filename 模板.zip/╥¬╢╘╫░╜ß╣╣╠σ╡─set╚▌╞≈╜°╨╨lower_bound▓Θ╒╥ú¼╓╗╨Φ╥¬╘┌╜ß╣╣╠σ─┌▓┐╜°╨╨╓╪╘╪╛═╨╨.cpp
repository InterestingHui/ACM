#include <bits/stdc++.h>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define Set set<int>
#define int long long
#define P pair<int,int>
const int maxn = 1e6+5;
const int INF = 1e17 +6;
using namespace std;
int n,m,a[maxn],b[maxn],ans,sum;
struct node{
    int v,w;
    bool operator<(const node&a)const{
        return w<a.w;
    }
};
multiset<node>T;
int32_t main()
{
    IOS;
    fu(i,1,10)
    {
        T.insert({i,i*10});
    }
    for(auto i:T)cout<<i.v<<" "<<i.w<<endl;
    fu(i,1,15) {
        cout<<"i:"<<i<<" i+1:"<<i+1<<endl;
        auto h = T.lower_bound({i, i+1});
        cout << "hh" << endl;
        cout << (*h).v << " " << (*h).w << endl;
    }
    /*
     �����ʾ
     1 10
2 20
3 30
4 40
5 50
6 60
7 70
8 80
9 90
10 100
i:1 i+1:2
hh
1 10
i:2 i+1:3
hh
1 10
i:3 i+1:4
hh
1 10
i:4 i+1:5
hh
1 10
i:5 i+1:6
hh
1 10
i:6 i+1:7
hh
1 10
i:7 i+1:8
hh
1 10
i:8 i+1:9
hh
1 10
i:9 i+1:10
hh
1 10
i:10 i+1:11
hh
2 20
i:11 i+1:12
hh
2 20
i:12 i+1:13
hh
2 20
i:13 i+1:14
hh
2 20
i:14 i+1:15
hh
2 20
i:15 i+1:16
hh
2 20
     */
    return 0;
}
