#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int INF=LLONG_MAX-1e10;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e6+1e5;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans,p[maxn];
struct node{
    int l,r,dis,val;
}st[maxn];
int Find(int x) { return (p[x] == x) ? p[x] : (p[x] = Find(p[x])); } // »Ø¹éÊ±Ñ¹ËõÂ·¾¶
int merge(int x,int y)
{
    if(!x or !y)return x+y;
    if(st[x].val>st[y].val or st[x].val==st[y].val && x>y)swap(x,y);
    st[x].r=merge(st[x].r,y);
    int R=st[x].r;
    p[R]=x;
    if(st[st[x].l].dis<st[R].dis)swap(st[x].l,st[x].r);
    st[x].dis=st[R].dis+1;
    return x;
}
void pop(int x)
{
    st[x].val=-1;
    p[x]=p[st[x].l]=p[st[x].r]=merge(st[x].l,st[x].r);
}
main()
{
    IOS
    cin>>n>>m;
    st[0].dis=-1;
    fun(i)
    {
        int x;
        cin>>x;
        st[i].val=x;
        p[i]=i;
    }
    fum(i)
    {
        int o;
        cin>>o;
        if(o==1)
        {
            int x,y;
            cin>>x>>y;
            if(st[x].val==-1 or st[y].val==-1 or Find(x)==Find(y))continue;
            int fx=Find(x),fy=Find(y);
            p[fx]=p[fy]=merge(fx,fy);
        }else{
            int x;
            cin>>x;
            if(st[x].val==-1) {
                out(-1)
            }else {
                out(st[Find(x)].val)
                pop(p[x]);
            }
        }
    }
    return 0;
}
