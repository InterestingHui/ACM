const int maxn=1e6+1e5;
int fac[maxn],hs1[maxn],hs2[maxn],inv[maxn],p1[maxn],p2[maxn];
const int N=6e5+10,M=2e5,MOD=998244353,MOD1=1e9+7,MOD2=1e9+9,bs1=233,bs2=234;
void init()
{
    fac[0]=inv[1]=p1[0]=p2[0]=1;
    fu(i,1,N-1)
    {
        fac[i]=1LL*fac[i-1]*i%MOD;
        if(i!=1)inv[i]=1LL*(MOD-MOD/i)*inv[MOD%i]%MOD;
        p1[i]=1LL*p1[i-1]*bs1%MOD1;
        p2[i]=1LL*p2[i-1]*bs2%MOD2;
    }
}
struct Hash{
    ll hs[N];
    int hd[M]={0,},nx[N],v[N],tot=0;
    int st[N],top=0;
    void add(ll h,int x){
        int o=h%M;
        for(int i=hd[o];i;i=nx[i]){
            if(hs[i]==h){
                v[i]+=x; return;
            }
        }
        ++tot; v[tot]=x; hs[tot]=h;
        nx[tot]=hd[o]; hd[o]=tot; st[++top]=o;
    }
    int que(ll h){
        int o=h%M;
        for(int i=hd[o];i;i=nx[i]){
            if(hs[i]==h){
                return v[i];
            }
        }
        return 0;
    }
    void clear(){
        tot=0;
        while(top){
            hd[st[top]]=0; --top;
        }
    }
}A,B;
void solve()
{
    cin>>n;
    fun(i)
    {
        string k;cin>>k;
        int now=0;
        fa(j,k)now=(1LL*now*bs1+j-'a')%MOD;
        A.add(now,1);
    }
    out(A.tot)
    return ;
}
