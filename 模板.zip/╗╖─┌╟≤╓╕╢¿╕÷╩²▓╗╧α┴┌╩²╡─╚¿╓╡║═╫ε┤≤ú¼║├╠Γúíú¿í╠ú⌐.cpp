#include<bits/stdc++.h>
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define int long long
#define INF 1e10
#define P pair<int,int>
using namespace std;
const int maxn = 2e5+10;
int n,m,a[maxn],b[maxn],MAX=0,MIN=0;
priority_queue<P>T;
int disvis[maxn];
P l[maxn],r[maxn];
int32_t main(){
	IOS;
	cin>>n>>m;
	fu(i,1,n)
	{
		cin>>a[i];
		T.push({a[i],i});
		l[i]={a[i-1],i-1};
		r[i-1]={a[i],i};
	}
	if(n==1)
	{
		cout<<a[1]<<endl;
		return 0;
	}
	if(2*m>n){
		cout<<"Error!";
		return 0;
	}
	l[1]={a[n],n};
	r[n]={a[1],1};
	int ans=0;
	fu(i,1,m)
	{
		auto k=T.top();
		T.pop();
		while(disvis[k.second])
		{
			k=T.top();
			T.pop();
		}
		auto left=l[k.second];
		auto right=r[k.second];
		disvis[left.second]=1;
		disvis[right.second]=1;
		auto new_left=l[left.second];
		auto new_right=r[right.second];
		P K={left.first+right.first-k.first,k.second};
		l[K.second]=new_left;
		r[K.second]=new_right;
		r[new_left.second]=K;
		l[new_right.second]=K;
		T.push(K);
//		cout<<k.first<<" "<<k.second<<endl;
		ans+=k.first;
	}
	cout<<ans;
    return 0;
}
