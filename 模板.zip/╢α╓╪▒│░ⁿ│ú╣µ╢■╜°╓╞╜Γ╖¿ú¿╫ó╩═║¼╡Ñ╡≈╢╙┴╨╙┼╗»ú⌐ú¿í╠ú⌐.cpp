#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int INF=LLONG_MAX/2;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e6+1e5;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
vc<P>have;
void deal(int v,int w,int d)
{
    int be=1;
    while(d>=be)
    {
        have.pb({be*v,be*w});
        d-=be;
        be<<=1;
    }
    if(d)have.pb({d*v,d*w});
}
int f[maxn];
main()
{
    IOS
    int C;
    cin>>n>>m>>C;
    fun(i)
    {
        int v,w,d;
        cin>>v>>w>>d;
        deal(v,w,d);
//        fu(k,0,v-1)//���ر������������Ż�����
//        {
//            int head=1,tail=0;
//            for(int j=k;j<=C;j+=v)
//            {
//                while(tail>=head && Queue[tail]<=f[j]-j/v*w)tail--;
//                Queue[++tail]=f[j]-j/v*w;
//                pos[tail]=j;
//                while(j-pos[head]>d*v)head++;
//                f[j]=max(f[j],Queue[head]+j/v*w);
//            }
//        }
    }
    fa(i,have)
    {
        fd(j,C,i.fi)
        {
            f[j]=max(f[j],f[j-i.fi]+i.se);
        }
    }
    fum(i){
        int x,y,z;
        cin>>x>>y>>z;
        fd(j,C,0) {
            fu(l, 0, j)f[j] = max(f[j], f[j - l] + x * l * l + y * l + z);
        }
    }
    out(f[C])
    return 0;
}
