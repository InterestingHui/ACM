#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define fu(i,l,r) for(int i=(l);i<=(r);i++)
#define P pair<int,int>
#define int long long
#define Rand rand()%10
const int maxn=1e5+5;
using namespace std;
int n,m;
struct that{
    int l,r;
};
set<that>T;//注意不能改成ms,否则find会很奇怪，明明里面有交集线段，但是找不到！
bool operator<(const that& L, const that& R) {
    return L.r<R.l;
}
int32_t main()
{
    IOS;
    cin>>n;
    fu(i,1,n)
    {
        int x,y;
        cin>>x>>y;
        that hh={x,y};
        auto h=T.find(hh);
        while(h!=T.end())
        {
            int qian=(*h).l,hou=(*h).r;
            T.erase(h);
            hh={min(qian,x),max(hou,y)};
            x=hh.l;
            y=hh.r;
            h=T.find(hh);
        }
        T.insert(hh);
        cout<<T.size()<<" ";
    }
    return 0;

}
