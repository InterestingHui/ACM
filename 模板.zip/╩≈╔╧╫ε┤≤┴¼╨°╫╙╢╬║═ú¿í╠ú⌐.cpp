#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
//#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
//#define x) ((x+mo_num)%mo_nu)
#define vc vector
#define vct vector<int>
#define fa(i,V) for(auto i:V)
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define got(container,num) get<num-1>(container)
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
using namespace std;
const int INF=LLONG_MAX-1e10;
const int maxn=5e5+10;
int n,m,a[maxn],b[maxn],ans;
struct edge{
    int to,val,next;
}e[maxn];
int head[maxn],cnt,dep[maxn],Fa[maxn],Size[maxn],son[maxn],top[maxn],Time,arr[maxn],Start[maxn],root;
struct node{
    long long sum,maxl,maxr,val;
}st[maxn<<1];
void add(int x,int y,int c)
{
    e[cnt]={y,c,head[x]};
    head[x]=cnt++;
}
node pushup(node w,node e)
{
    node q;
    q.sum=w.sum+e.sum;
    q.val=max({w.val,e.val,w.maxr+e.maxl});
    q.maxr=max(e.maxr,e.sum+w.maxr);
    q.maxl=max(w.maxl,w.sum+e.maxl);
    return q;
}
void build(int rt,int l,int r)
{
    if(l==r){
        st[rt]={arr[l],arr[l],arr[l],arr[l]};
        return;
    }
    MM;
    build(lson);
    build(rson);
    st[rt]=pushup(st[ls],st[rs]);
}
void dfs1(int now,int f,int deep)
{
    dep[now]=deep;
    Fa[now]=f;
    Size[now]=1;
    int mson=-1;
    fh(i,now,e)
    {
        if(e[i].to==f)continue;
        dfs1(e[i].to,now,deep+1);
        Size[now]+=Size[e[i].to];
        if(Size[e[i].to]>mson)mson=Size[e[i].to],son[now]=e[i].to;
    }
}
void dfs2(int now,int topf)
{
    top[now]=topf;
    Start[now]=++Time;
    arr[Time]=a[now];
    if(!son[now])return ;
    dfs2(son[now],topf);
    fh(i,now,e)
    {
        if(e[i].to==son[now] or e[i].to==Fa[now])continue;
        dfs2(e[i].to,e[i].to);
    }
}
node query(int rt,int l,int r,int L,int R)
{
    if(l>=L && r<=R)return st[rt];
    MM;
    return M>=L && M+1<=R?pushup(query(lson,L,R),query(rson,L,R)):M>=L?query(lson,L,R):query(rson,L,R);
}
long long quechain(int x,int y)
{
    node L={0,0,0,-INF},R={0,0,0,-INF};
    while(top[x]!=top[y])
    {
        if(dep[top[x]]>dep[top[y]]) {
            L = pushup(query(1, 1, n, Start[top[x]], Start[x]), L);
            x=Fa[top[x]];
        }else{
            R=pushup(query(1,1,n,Start[top[y]],Start[y]),R);
            y=Fa[top[y]];
        }
    }
    node Ans={0,0,0,-INF};
    if(dep[x]<dep[y])
    {
        Ans=pushup(query(1,1,n,Start[x],Start[y]),R);
        swap(L.maxl,L.maxr);
        Ans=pushup(L,Ans);
    }else{
        Ans=pushup(query(1,1,n,Start[y],Start[x]),L);
        swap(R.maxl,R.maxr);
        Ans=pushup(R,Ans);
    }
    return Ans.val;
}
main()
{
    IOS

    cin>>n;
    memset(head,-1,sizeof(head));
    fu(i,1,n-1)
    {
        int u,v;
        cin>>u>>v;
        add(u,v,1);
        add(v,u,1);
    }
    root=1;
    fun(i)cin>>a[i];
    dfs1(root,0,1);
    dfs2(root,root);
    build(1,1,n);
    cin>>m;
    fum(i)
    {
        int l,r;
        cin>>l>>r;
        out(quechain(l,r))
    }
    return 0;
}
