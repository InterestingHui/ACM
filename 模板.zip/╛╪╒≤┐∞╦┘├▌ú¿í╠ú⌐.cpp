#include<bits/stdc++.h>
#define SZ(x) ((int)x.size())
#define uni(x) sort(all(x)),x.resize(unique(all(x))-x.begin());
#define GETPOS(c,x) (lower_bound(all(c),x)-c.begin())
#define lown1(x,val) low(in(x),val)-x
#define lowm1(x,val) low(im(x),val)-x
#define low1(x,val,nums) low(x+1,x+nums+1,val)-x
#define mst(x,val) memset((x),val,sizeof((x)));
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define far(i,V) for(auto &i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define eps 1e-6
//Remember cancel"#define endl '\n'" in interactive questions or use "<<flush"
#define endl '\n'
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
//#define yn(key) out(key?"Yes":"No")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define ik(i,k) i+1,i+1+k
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
#define db double
#define got(container,num) get<num-1>(container)
#define int long long
#define print(a,n) fun(i)cout<<a[i]<<(i!=n?' ':endl);
using namespace std;
//Remember to cancel the line below and declare INT=INT_MAX/2; when you want to change long to int
const int INF=LLONG_MAX/4,SINF=0x3f3f3f3f,Lim=1<<20,MINF=LLONG_MAX;
//const int INF=INT_MAX/4;
// use C:printf("%.16f", x);  ->  printf("%.10f", x); can accelerate the program
//typedef unsigned long long ull; template<class T> void _R(T &x) { cin >> x; }void _R(int32_t &x) { scanf("%d", &x); }void _R(long long &x) { scanf("%lld", &x); }void _R(ull &x) { scanf("%llu", &x); }void _R(double &x) { scanf("%lf", &x); }void _R(char &x) { scanf(" %c", &x); }void _R(char *x) { scanf("%s", x); }void R() {}template<class T, class... U> void R(T &head, U &... tail) { _R(head); R(tail...); }template<class T> void _W(const T &x) { cout << x; }void _W(const int32_t &x) { printf("%d", x); }void _W(const long long &x) { printf("%lld", x); }void _W(const double &x) { printf("%.16f", x); }void _W(const char &x) { putchar(x); }void _W(const char *x) { printf("%s", x); }template<class T,class U> void _W(const pair<T,U> &x) {_W(x.F); putchar(' '); _W(x.S);}template<class T> void _W(const vector<T> &x) { for (auto i = x.begin(); i != x.end(); _W(*i++)) if (i != x.cbegin()) putchar(' '); }void W() {}template<class T, class... U> void W(const T &head, const U &... tail) { _W(head); putchar(sizeof...(tail) ? ' ' : '\n'); W(tail...); }
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=2e5+5;
const int mo_num=1e9+7;
//const int mo_num=998244353;
int n,m,t,a[maxn],b[maxn],ans;
int state[maxn],num;
int val[maxn][4];
int L[maxn],R[maxn],row[maxn];
const int N=4;//����ı߳���С,ʵ����Ҫ�Լ�����
struct Matrix {
    int c[N][N];

    //���ʹ����������,������������Matrix������ʱ����Զ���ʼ��ΪINF���������ʹ����Matrix A(3);������Ϊ��ʼ����������Ԫ��Ϊ3��
    //Matrix(int x = INF) { memset(c, 0x3f, sizeof(c)); for (int i = 0; i < N; i++) c[i][i] = x; }
    Matrix(){mst(c,0);}
    int*operator [](int x) { return c[x]; }//���غ��ֱ����A[i][j],����A.c[i][j]
    const int*operator [](int x) const { return c[x]; }
} A;
Matrix operator*(const Matrix &x,const Matrix &y) {//ע�⣬����Ĭ�Ͼ���ı߳���n!
    Matrix a;
    fu(i,1,3)
        fu(j,1,3) {
            a[i][j]=0;
            fu(k,1,3) {
                a[i][j]=mod(a[i][j]+x[i][k]*y[k][j]);
//                a[i][j]=x[i][k]*y[k][j] ;
            }
        }
    return a;
}
Matrix POW(int k,Matrix I)
{
    Matrix A=I;
    k--;
    while(k>0) {
        if(k%2==1) I=I*A;
        A=A*A;
        k=k>>1;
    }
    return I;
}
void solve()
{
    cin>>n>>m;
    fun(i)
    {
//        int row,l,r;
        cin>>row[i]>>L[i]>>R[i];
        R[i]++;
        state[++num]=L[i],state[++num]=R[i];
    }
    state[++num]=2,state[++num]=m+1;
    sort(ik(state,num));num=unique(ik(state,num))-state-1;
    fun(i)
    {
        int l=low1(state,L[i],num),r=low1(state,R[i],num);
        val[l][row[i]]++,val[r][row[i]]--;
    }
    Matrix A;
    A[2][2]=1;
    fu(now,1,num-1)
    {
        int len=state[now+1]-state[now];
        fu(i,1,3)b[i]+=val[now][i];
        Matrix I;
        fu(k1,1,3)
        {
            fu(k2,max((int)1,k1-1),min((int)3,k1+1))
            {
                I[k1][k2]=!b[k2];
            }
        }
        A=A*POW(len,I);
    }
    out(A[2][2])
    return ;
}
main()
{
    IOS
    int T=1;
    //cin>>T;
    while(T--)solve();
    return 0;
}

/*��������
start in(2,1),go to (2,m)
ÿһ��(i,j)�Ĳ���:
(i-1,j+1) if i>1
(i,j+1),
(i+1,j+1) if i<3
*/
