#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
//#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e6+1e5;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
int belong[maxn],cnt[maxn],now;
struct query{
    int num,l,r,t;
}have[maxn];

struct nn{
    int x,y;
}TIME[maxn];

//��ѯ�����������
int cmp(query a, query b) {

    return belong[a.l] == belong[b.l] ? belong[a.r]==belong[b.r]?a.t<b.t:belong[a.r]<belong[b.r] : belong[a.l] < belong[b.l];
}
//��ָ�����ơ���ָ������
void add(int pos) {
    if(!cnt[a[pos]]) ++now;
    ++cnt[a[pos]];
}

//��ָ�����ơ���ָ������
void del(int pos) {
    --cnt[a[pos]];
    if(!cnt[a[pos]]) --now;
}

void update(int xu,int Time)
{
    if(have[xu].l<=TIME[Time].x && have[xu].r>=TIME[Time].x)
    {
        del(TIME[Time].x);
        now+=!cnt[TIME[Time].y]++;
    }
    swap(a[TIME[Time].x],TIME[Time].y);
}
int Ans[maxn];
main()
{
//    n=read(),m=read();
    IOS
    cin>>n>>m;
    fun(i)cin>>a[i];
    int Time=0,num=0;
    fum(i)
    {
        char o;
        cin>>o;
        if(o=='Q')
        {
            int l,r;
            cin>>l>>r;
            have[++num]={num,l,r,Time};
        }else{
            int x,y;
            cin>>x>>y;
            TIME[++Time]={x,y};
        }
    }
    int block=ceil(pow(n,0.75));
    fun(i)belong[i]=(i-1)/block+1;
    sort(have+1,have+num+1,cmp);
    int l=have[1].l,r=have[1].l-1;
    t=0;
    fu(i,1,num)
    {
        while(l < have[i].l) del(l++);
        while(l > have[i].l) add(--l);
        while(r < have[i].r) add(++r);
        while(r > have[i].r) del(r--);
        while(t<have[i].t)update(i,++t);
        while(t>have[i].t)update(i,t--);
        Ans[have[i].num]=now;
    }
    fu(i,1,num)
    {
        out(Ans[i])
    }
    return 0;
}
