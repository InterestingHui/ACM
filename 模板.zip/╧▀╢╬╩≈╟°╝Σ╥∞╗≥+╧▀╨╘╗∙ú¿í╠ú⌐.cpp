#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=3e5+10;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
int st[maxn<<3][34];
void add(int rt,int val)
{
    fd(i,31,0)
    {
        if(!(val>>i))continue;
        if(!st[rt][i])
        {
            st[rt][i]=val;
            break;
        }else{
            val^=st[rt][i];
        }
    }
}
void pushup(int rt)
{
    fu(i,0,31)st[rt][i]=0;
    fd(i,31,0)
    {
        if(st[ls][i])add(rt,st[ls][i]);
        if(st[rs][i])add(rt,st[rs][i]);
    }
}

void build(int rt,int l,int r)
{
    if(l==r)
    {
        fu(i,0,31)st[rt][i]=0;
        add(rt,b[l]);
        return ;
    }
    MM;
    build(lson);
    build(rson);
    pushup(rt);
}
int f[maxn];
void Update(int pos,int val){ for(int i=pos;i<=n;i+=lowbit(i)) f[i] ^= val; }

//���A1~Apos
int getsum(int pos){ int num = 0;for(int i=pos;i;i-=lowbit(i))num ^= f[i];return num; }
//���Ҫ��Ax~Ay:int num=getsum(y,a)-getsum(x-1,a);
void query(int rt,int l,int r,int L,int R)
{
    if(L<=l && r<=R)
    {
        fd(i,31,0)
        {
            if(st[rt][i])add(0,st[rt][i]);
        }
        return ;
    }
    MM;
    if(M>=L)query(lson,L,R);
    if(M<R)query(rson,L,R);
}
void update(int rt,int l,int r,int x)
{
    if(l==r)
    {
        fu(i,0,31)st[rt][i]=0;
        add(rt,b[x]);
        return;
    }
    MM;
    if(M>=x)update(lson,x);
    else update(rson,x);
    pushup(rt);
    return;
}
void Clear(int rt,int l,int r)
{
    fu(i,0,31)st[rt][i]=0;
    if(l==r)return ;
    MM;
    Clear(lson);
    Clear(rson);
}
int Pow(int a, int b) {
    int ans = 1, base = a;
    while (b != 0) {
        if (b & 1 != 0)
            ans *= base;
        base *= base;
        b >>= 1;
    }
    return ans;
}
main()
{
    IOS
    cin>>t;
//    t=1;
    fut(qwe) {
        cin >> n >> m;
        fun(i) {
            cin >> a[i];
            f[i]=0;
            if (i >= 2)b[i - 1] = a[i - 1] ^ a[i];
        }
        if (n == 1) {
            int x;
            fum(i) {
                int o, l, r, k;
                cin >> o >> l >> r;
                if (o == 1)cin >> k, a[1] ^= k; else out(a[1] ? 2 : 1);
            }
            fu(i,0,n)a[i]=f[i]=b[i]=0;
            continue;
        }
        build(1, 1, n - 1);

        fum(i) {
            int o, l, r, k;
            cin >> o;
            if (o == 1) {
                cin >> l >> r >> k;
                if (l >= 2) {
                    b[l - 1] ^= k;
                    update(1, 1, n - 1, l - 1);
                }
                if (r < n) {
                    b[r] ^= k;
                    update(1, 1, n - 1, r);
                }
                Update(l, k);
                if(r<n)Update(r + 1, k);
            } else {
                cin >> l >> r;
                fu(j, 0, 31)st[0][j] = 0;
                add(0, a[l] ^ getsum(l));
                if (r >= 2 && r>l)query(1, 1, n - 1, l, r - 1);
                ans = 0;
                fu(j, 0, 31)ans += (st[0][j] > 0);
                out(Pow(2, ans))
            }
        }
        Clear(1,1,n-1);
        fu(i,0,31)st[0][i]=0;
        fu(i,0,n)a[i]=f[i]=b[i]=0;
    }
    return 0;
}
