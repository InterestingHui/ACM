#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
#define got(container,num) get<num-1>(container)
using namespace std;
const int INF=LLONG_MAX/2;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=2e5+10;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
int L[maxn][25],R[maxn][25],Ans[maxn];
void dfs(int l,int r,vc<tuple<int,int,int>>h)
{
    MM;
    fu(i,M,r)fu(j,0,m-1)R[i][j]=0;
    fu(i,l,M+1)fu(j,0,m-1)L[i][j]=0;
    R[M][0]=1;
    L[M+1][0]=1;
    fu(i,M+1,r)
        fu(j,0,m-1)
            R[i][j]=mod(R[i-1][j]+R[i-1][(j-a[i]+m)%m]);
    fd(i,M,l)
        fu(j,0,m-1)
            L[i][j]=mod(L[i+1][j]+L[i+1][(j-a[i]+m)%m]);
    vc<tuple<int,int,int>>Z,Y;
    fa(i,h)
    {
        int z=got(i,1),y=got(i,2),id=got(i,3);
        if(z<=M && M+1<=y)
        {
            fu(j,0,m-1)Ans[id]=mod(Ans[id]+L[z][j]*R[y][(m-j)%m]);
        }else if(y<=M)
        {
            Z.pb(i);
        }else Y.pb(i);
    }
    if(l<M && !Z.empty())dfs(l,M,Z);
    if(M+1<r && !Y.empty())dfs(M+1,r,Y);
}
main()
{
    IOS
    cin>>n>>m;
    fun(i)
    {
        cin>>a[i];
        a[i]=a[i]%m;
    }
    cin>>t;
    vc<tuple<int,int,int>> gget;
    fut(o)
    {
        int l,r;
        cin>>l>>r;
        if(l==r)
        {
            Ans[o]=!a[l]?2:1;
        }else gget.pb(mk(l,r,o));
    }
    dfs(1,n,gget);
    fut(i)
    {
        out(Ans[i])
    }
    return 0;
}
