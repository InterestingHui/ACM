#include<bits/stdc++.h>
#define ls root<<1
#define rs root<<1|1
#define lson root<<1,l,M
#define rson root<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define fa(i,V) for(auto i:V)
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define got(container,num) get<num-1>(container)
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
using namespace std;
const int INF=LLONG_MAX-1e10;
const int maxn=2e5+1e5;
const int mo_num=1e9+7;
int n,m,a[maxn],b[maxn],ans;
int root[maxn],lc[maxn<<4],rc[maxn<<4],sum[maxn<<4],cnt,kinds,Data[maxn];
void build(int &rt,int l,int r)
{
    rt=++cnt,sum[rt]=0;
    if(l==r)return ;
    MM;
    build(lc[rt],l,M);
    build(rc[rt],M+1,r);
}
int update(int past,int l,int r,int val)
{
    int built=++cnt;
    lc[built]=lc[past],rc[built]=rc[past],sum[built]=sum[past]+1;
    if(l==r)return built;
    MM;
    if(M>=val)lc[built]=update(lc[built],l,M,val);
    else rc[built]=update(rc[built],M+1,r,val);
    return built;
}
int query(int z,int y,int l,int r,int num)
{
    MM;
    int left=sum[lc[y]]-sum[lc[z]];
    if(l==r)return l;
    return left>=num?query(lc[z],lc[y],l,M,num):query(rc[z],rc[y],M+1,r,num-left);
}

main() {
    IOS
    cin >> n >> m;
    fun(i)cin >> a[i], Data[i] = a[i];
    sort(in(Data));//Data用于离散化
    kinds = unique(in(Data))-Data-1;//权值种类数
    fun(i)b[i] = low(Data+1,Data+1+kinds, a[i]) - Data;//b[i]是a[i]离散化后的东西
    build(root[0], 1, kinds);
    fun(i)root[i]=update(root[i-1],1,kinds,b[i]);
    fum(i)
    {
        int l,r,k;
        cin>>l>>r>>k;
        out(Data[query(root[l-1],root[r],1,kinds,k)])
    }
    return 0;
}
