#include <bits/stdc++.h>
using namespace std;
#define maxn 1000010
#define Maxn maxn+10
#define maxk 50
typedef long long ll;
ll prime[Maxn],phi[Maxn],pn=0;
bool jud[Maxn];
void init(){
	phi[1]=1;
	for(int i=2;i<=maxn;i++){
		if(!jud[i]){
			prime[++pn]=i;phi[i]=i-1;
		}
		for(int j=1;j<=pn;j++){
			ll cnt=i*prime[j];
			if(cnt>maxn)break;
			jud[cnt]=true;
			if(i%prime[j]==0){
				phi[cnt]=phi[i]*prime[j];break;
			}
			else{
				phi[cnt]=phi[i]*(prime[j]-1);
			}
		}
	}
}
ll f_pow(ll x,ll p,ll mod)
{
	ll ans=1;
	while(p){
		if(p%2==1){
			ans*=x;ans%=mod;
		}
		x*=x;x%=mod;p/=2;
	}
	return ans;
}
ll solve(ll a,ll b,ll p){
	if(p==1)return 0;
	if(b==0)return 1;
	ll P=solve(a,b-1,phi[p]);
	/*printf("b=%lld P=%lld p=%lld\n",b,P,p);*/
	if(P<phi[p]&&P) return f_pow(a,P,p);
	else return f_pow(a,P+phi[p],p);
}
ll gcd(ll a,ll b){
	return b==0?a:gcd(b,a%b);
}
int main()
{
	init();
	int t;scanf("%d",&t);
	while(t--){
		ll a,b,mod;scanf("%lld%lld%lld",&a,&b,&mod);
		ll g=gcd(a,mod);ll ans;
		ans=solve(a,b,mod);
		printf("%lld\n",ans%mod);
	}
	return 0;
}

/* input
5
2 0 3
3 1 2
3 1 100
3 2 16
5 3 233
output
1
1
3
11
223

a b c
ask for (((a^a)^a)^a..)%c   :number of (a^..) is b
*/
