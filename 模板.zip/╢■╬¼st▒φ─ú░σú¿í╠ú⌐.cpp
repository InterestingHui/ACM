#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
//#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
//const int INF=LLONG_MAX-1e10;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e6+1e5;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
int H[maxn];
const int N=505;
int GCD[505][505][12][12];
int query(int x,int y,int len)
{
    int i=x-len,j=y-len;
    int ir=x+len,jr=y+len;
    int k=log2(2*len+1);
//    return max(Max[l][k],Max[r-(1<<k)+1][k]);//�Ѳ����������ֱ�ȡ��ֵ
    return __gcd(__gcd(GCD[i][j][k][k],GCD[i][jr-(1<<k)+1][k][k]),__gcd(GCD[ir-(1<<k)+1][j][k][k],GCD[ir-(1<<k)+1][jr-(1<<k)+1][k][k]));
}

inline int read()
{
    int x=0,f=1;char ch=getchar();
    while (!isdigit(ch)){if (ch=='-') f=-1;ch=getchar();}
    while (isdigit(ch)){x=x*10+ch-48;ch=getchar();}
    return x*f;
}
bool check(int border)
{
    fu(i,1+border,n-border)
    fu(j,1+border,m-border)
    {
        if(query(i,j,border)==GCD[i][j][0][0])ans++;
    }
    return ans?1:0;
}
main()
{
    n=read(),m=read();
//    cin>>n>>m;
    fun(i) {
        int x;
        fum(j)GCD[i][j][0][0]=read();
//        fum(j)cin>>x,GCD[i][j][0][0]=GCD[i][j][0][1]=x;
    }
    //GCD[i][j][k][]
    fun(heng)//����һά
        fu(j,1,10)
            fu(i,1,m+1-(1<<j))
                GCD[heng][i][j][0]=__gcd(GCD[heng][i][j-1][0],GCD[heng][i+(1<<(j-1))][j-1][0]);
    fum(shu)//������ά
        fu(j,1,10)
            fu(i,1,n+1-(1<<j))
                fu(k,1,10)
                    GCD[i][shu][k][j]=__gcd(GCD[i][shu][k][j-1],GCD[i+(1<<(j-1))][shu][k][j-1]);

    int l=0,r=min((n-1)/2,(m-1)/2);
    while (l < r)
    {
        int mid = l + r + 1 >> 1;
        ans=0;
        if (check(mid)) l = mid;//�����м�����,����һ�����������Ĵ���ֵ
        else r = mid - 1;
    }
    int L=l*2+1;
    ans=0;
    check(l);
    out(L*L)
    out(ans)
    return 0;
}
