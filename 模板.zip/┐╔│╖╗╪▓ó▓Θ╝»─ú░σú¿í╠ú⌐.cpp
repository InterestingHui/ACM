struct DSU {
    stack<pair<int,int> >stk;
    int p[maxn],siz[maxn];
    void init(int x) {
        fu(i,1,x+1){
            p[i] = i;
            siz[i] = 1;
        }
    }
    int Find(int x) {
        return x == p[x] ? x : Find(p[x]);
    }
    bool merge(int x,int y) {
        int rx = Find(x),ry = Find(y);
        if(rx == ry) return false;
        if(siz[rx] > siz[ry]) swap(rx,ry);
        p[rx] = ry;
        siz[ry] += siz[rx];
        stk.push({rx,ry});
        return true;
    }
    void undo() {
        pair<int,int>now = stk.top();
        p[now.first] = now.first;
        siz[now.second] -= siz[now.first];
        stk.pop();
    }
}dsu;//��������滷��Enemies��Ҫ�Լ����أ����������dsu.init(n)!
