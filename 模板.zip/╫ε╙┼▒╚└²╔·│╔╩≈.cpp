#include <bits/stdc++.h>
//#pragma comment(linker, "/STACK:1024000000,1024000000")
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define Set set<int>
#define int long long
#define P pair<int,int>
const int maxn = 1e3+6;
const int INF = 2e9;
using namespace std;
//int n,m,a[maxn],b[maxn],c[maxn];
int n,m,vis[maxn][maxn];
struct node{
    int x,y,z,id;
};
vector<node>T;
struct edge{
    int u,v,h;
    double d;
};
vector<edge>E;
struct node2{
    int u,v;
    double w;
    bool operator<(const node2&a)const{
        return w<a.w;
    }
};
vector<node2>need[1001];
int fa[1001][maxn],ANS,cnt;
double MIN;
int find(int i){return (fa[cnt][i]==i)?fa[cnt][i]:(fa[cnt][i]=find(fa[cnt][i]));}
bool can(double ans)
{
    for(auto i:E)
    {
        need[cnt].push_back({i.u,i.v,i.h-ans*i.d});
    }
    sort(need[cnt].begin(),need[cnt].end());
    double sum=0,all_ans=0;
    for(auto i:need[cnt])
    {
        int aa=find(i.v);
        int bb=find(i.u);
        if(bb!=aa)
        {
            sum++;
            fa[cnt][aa]=bb;
            all_ans+=i.w;
            if(sum==n-1)break;
        }
    }
            cnt++;
    if(all_ans<=0 ){
//        MIN=all_ans;
        return 1;
    }else{
        return false;
    }
}
bool can2(int mid)
{
    double ans=mid/(double)1000;
    for(auto i:E)
    {
        need[cnt].push_back({i.u,i.v,i.h-ans*i.d});
    }
    sort(need[cnt].begin(),need[cnt].end());
    double sum=0,all_ans=0;
    for(auto i:need[cnt])
    {
        int aa=find(i.v);
        int bb=find(i.u);
        if(bb!=aa)
        {
            sum++;
            fa[cnt][aa]=bb;
            all_ans+=i.w;
            if(sum==n-1)break;
        }
    }
    cnt++;
    if(all_ans>=0)return 1;
    else return 0;
}
int32_t main() {
    IOS;
    cin >> n;
    fu(j, 1, n)
    {
        int x,y,z;
        cin>>x>>y>>z;
        for(auto i:T){
            E.push_back({i.id,j,abs(i.z-z),(double)sqrt(abs(i.x-x)*abs(i.x-x)+abs(i.y-y)*abs(i.y-y))});
        }
        T.push_back({x,y,z,j});
    }
    fu(i,1,n) {
        fu(j,0,1000)fa[j][i] = i;
    }

//    for(auto i:T)
//    {
//        for(auto j:T)
//        {
//            if(i.id==j.id or vis[i.id][j.id])continue;
//            vis[i.id][j.id]=1;
//            vis[j.id][i.id]=1;
//            E.push_back({i.id,j.id,abs(i.z-j.z),(double)sqrt(abs(i.x-j.x)*abs(i.x-j.x)+abs(i.y-j.y)*abs(i.y-j.y))});
//        }
//    }
    double left = 0.001;
    double right = 1e5+0.001;
    // ��������� <=
    MIN=-INF-0.1;
//    can(500);
//    can(496);
//    can(495);
    double L=0.0,R=100.0;
    while(R-L>1e-6){
        double mid=(L+R)/2;
        if(!can(mid))L=mid;
        else R=mid;
    }

//    fu(i,0,100)if(can2(left+i))cout<<fixed<<setprecision(3)<<(double)(left+i);
    cout<<fixed<<setprecision(3)<<(double)L;
    return 0;
}
