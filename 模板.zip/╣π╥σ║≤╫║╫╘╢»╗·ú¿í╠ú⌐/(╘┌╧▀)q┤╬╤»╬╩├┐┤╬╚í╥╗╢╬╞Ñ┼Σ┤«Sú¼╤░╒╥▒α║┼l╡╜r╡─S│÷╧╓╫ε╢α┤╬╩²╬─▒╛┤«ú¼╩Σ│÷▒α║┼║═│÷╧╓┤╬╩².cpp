/*
����Ŀ������
����һ���ַ���s����m���ı�������ţ�number����1��m
Ȼ����t��ѯ�ʣ�ÿ��ѯ�ʸ���4������l��r��ql��qr������Ϊ��ȥ��s[ql,qr]��ΪS�����ڱ��[l,r]���ı�����
�ĸ��ı������д�������S�������������ı�ź�����ִ�������ÿ��ѯ�����������

��������
 �Ȱ������ı��������뵽����SAM�У�����ÿһ����㿪һ���±�Ϊ[1,m]�Ķ�̬�����߶���ά��siz
 ��ע�����sʱ�Ͳ�Ҫ���߶����Ͻ����޸Ĳ����ˣ�������siz��ά����ͳ�������ͣ����Բ��������Ҫ��parent���������߶����ϲ�
 ��ѯʱ����parent���ϱ����ҵ������Ӵ�s[ql,qr]�ĵȼ���״̬�ڵ㣬Ȼ���ڸõ���߶����ϲ�ѯ����[l,r]�е����ֵ��˳��ά�������ֵ������λ�ü��ɡ�
Input:
suffixtree
3
suffixtreesareawesome
cartesiantreeisworsethansegmenttree
nyeeheeheee
2
1 2 1 10
1 3 9 10

Output:
1 1
3 4


 */
#include<bits/stdc++.h>
#define SZ(x) ((int)x.size())
#define uni(x) sort(all(x)),x.resize(unique(all(x))-x.begin());
#define GETPOS(c,x) (lower_bound(all(c),x)-c.begin())
#define lown1(x,val) low(in(x),val)-x
#define lowm1(x,val) low(im(x),val)-x
#define low1(x,nums,val) low(x+1,x+nums+1,val)-x
#define mst(x,val) memset((x),val,sizeof((x)))
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define far(i,V) for(auto &i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define lcm(a,b) ((a)*(b))/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) ((x)&(-x))
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) (((x)<0)?(x)%mo_num+mo_num:(x)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define Umap unordered_map<int,int>
#define P pair<int,int>
#define SET set<int>
#define mk make_tuple
#define eps 1e-6
//Remember cancel"#define endl '\n'" in interactive questions or use "<<flush"
#define endl '\n'
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
//#define yn(key) out(key?"Yes":"No")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define ik(i,k) i+1,i+1+k
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
#define db double
#define ll long long
#define got(container,num) get<num-1>(container)
#define int long long
#define print(a,n) fun(i)cout<<a[i]<<(i!=n?' ':endl);
#define outcase(x) cout<<"Case #"<<(++case_of_T)<<": "<<(x)<<endl;
#define ptcase(x) printf("Case #%d: %d\n",++case_of_T,x);
#define plcase(x) printf("Case #%lld: %lld\n",++case_of_T,x);
using namespace std;
//Remember to cancel the line below and declare INT=INT_MAX/2; when you want to change long to int
const int INF=LLONG_MAX/4,SINF=0x3f3f3f3f,Lim=1<<20,MINF=LLONG_MAX;
//const int INF=INT_MAX/4,SINF=0x3f;
// use C:printf("%.16f", x);  ->  printf("%.10f", x); can accelerate the program
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//down up left right
const int maxn=5e5+10,maxm=5e4+3,logn=21;
int mo_num=1e9+7;
//const int mo_num=998244353;
int n,m,t,a[maxn],b[maxn],ans,case_of_T;
int pos[maxn];
string s,ch;
struct QWQ{
    int x,id;QWQ(int X=0,int ID=0){x=X,id=ID;}
    inline bool operator>(const QWQ &O)const{return x!=O.x?x>O.x:id<O.id;}
};
inline QWQ max(QWQ A,QWQ B){return A>B?A:B;}
int pt[maxn+maxm<<1];
struct Segment_Tree{
#define pl (tr[p].lp)
#define pr (tr[p].rp)
#define mid ((L+R)>>1)
    int O;
    struct QAQ{int lp,rp;QWQ ans;}tr[(maxm<<1)*30];
    inline void pushup(int p){
        tr[p].ans=max(tr[pl].ans,tr[pr].ans);
    }
    inline void change(int &p,int L,int R,int x){
        if(!p)p=++O;
        if(L==R){++tr[p].ans.x,tr[p].ans.id=L;return;}
        if(x<=mid)change(pl,L,mid,x);
        else change(pr,mid+1,R,x);
        pushup(p);
    }
    inline int merge(int p,int q,int L,int R){
        if(!p||!q)return p+q;
        int x=++O;
        if(L==R){tr[x]=tr[p],tr[x].ans.x+=tr[q].ans.x;return x;}
        tr[x].lp=merge(pl,tr[q].lp,L,mid);
        tr[x].rp=merge(pr,tr[q].rp,mid+1,R);
        pushup(x);return x;
    }
    inline QWQ ask(int p,int L,int R,int l,int r){
        if(!p)return QWQ(0,m+1);
        if(l<=L&&R<=r)return tr[p].ans;
        QWQ ans=QWQ(0,m+1);
        if(l<=mid)ans=max(ans,ask(pl,L,mid,l,r));
        if(r>mid)ans=max(ans,ask(pr,mid+1,R,l,r));
        return ans;
    }
}TR;
struct Suffix_Automaton{
    int O,link[maxn+maxm<<1],maxlen[maxn+maxm<<1],trans[maxn+maxm<<1][26];
    Suffix_Automaton(){O=1;}
    inline int insert(int ch,int last,int id){
        if(trans[last][ch]){
            int p=last,x=trans[p][ch];
            if(maxlen[p]+1==maxlen[x]){if(id)TR.change(pt[x],1,m,id);return x;}
            else{
                int y=++O;maxlen[y]=maxlen[p]+1;
                for(int i=0;i<26;++i)trans[y][i]=trans[x][i];
                while(p&&trans[p][ch]==x)trans[p][ch]=y,p=link[p];
                link[y]=link[x],link[x]=y;
                if(id)TR.change(pt[y],1,m,id);
                return y;
            }
        }
        int z=++O,p=last;maxlen[z]=maxlen[p]+1;
        while(p&&!trans[p][ch])trans[p][ch]=z,p=link[p];
        if(!p)link[z]=1;
        else{
            int x=trans[p][ch];
            if(maxlen[x]==maxlen[p]+1)link[z]=x;
            else{
                int y=++O;maxlen[y]=maxlen[p]+1;
                for(int i=0;i<26;++i)trans[y][i]=trans[x][i];
                while(p&&trans[p][ch]==x)trans[p][ch]=y,p=link[p];
                link[y]=link[x],link[x]=link[z]=y;
            }
        }
        if(id)TR.change(pt[z],1,m,id);
        return z;
    }
    int o,deep[maxn+maxm<<1],head[maxn+maxm<<1],ant[maxn+maxm<<1][23];
    struct QAQ{int to,next;}a[maxn+maxm<<1];
    inline void add(int x,int y){a[++o].to=y,a[o].next=head[x],head[x]=o;}
    inline void dfs(int x,int fa){
        deep[x]=deep[ant[x][0]=fa]+1;
        for(int i=1;(1<<i)<=deep[x];++i)ant[x][i]=ant[ant[x][i-1]][i-1];
        for(int i=head[x],to;i;i=a[i].next)
            dfs(to=a[i].to,x),pt[x]=TR.merge(pt[x],pt[to],1,m);
    }
    inline void build(){
        for(int i=2;i<=O;++i)add(link[i],i);dfs(1,0);
    }
    inline int get(int x,int len){
        int p=pos[x];
        for(int i=logn;i>=0;--i)if(ant[p][i]&&maxlen[ant[p][i]]>=len)p=ant[p][i];
        return p;
    }
    inline P calc(int l,int r,int x,int y){
        QWQ ans=TR.ask(pt[get(y,y-x+1)],1,m,l,r);
        if(ans.x==0)ans.id=l;
        return {ans.id,ans.x};
    }
}SAM;
void solve()
{
    cin>>s>>m;
    n=s.length();
    fum(i)
    {
        cin>>ch;
        int last=1;
        fa(j,ch)last=SAM.insert(j-'a',last,i);
    }
    int last=1;
    fun(i)pos[i]=last=SAM.insert(s[i-1]-'a',last,0);
    SAM.build();
    cin>>t;
    fut(o)
    {
        int l,r,x,y;
        cin>>l>>r>>x>>y;
        P gget=SAM.calc(l,r,x,y);
        cout<<gget.fi<<" "<<gget.se<<endl;
    }
    return ;
}
main()
{
    IOS
    int T=1;
    //cin>>T;
    while(T--)solve();
    return 0;
}
