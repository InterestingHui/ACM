#include <bits/stdc++.h>
using namespace std;

//Start
typedef long long ll;
typedef double db;
#define mp(a,b) make_pair((a),(b))
#define x first
#define y second
#define be(a) (a).begin()
#define en(a) (a).end()
#define sz(a) int((a).size())
#define pb(a) push_back(a)
#define R(i,a,b) for(int i=(a),I=(b);i<I;i++)
#define L(i,a,b) for(int i=(b)-1,I=(a)-1;i>I;i--)
const int iinf=0x3f3f3f3f;
const ll linf=0x3f3f3f3f3f3f3f3f;

//Data
const int N=1e6;
int n,qn;
string s;

//SuffixAutoMoton
const int tN=(N<<1)+1;
int tn,ch[tN][26],fa[tN],len[tN],sz[tN];
int newsam(){
	fill(ch[tn],ch[tn]+26,-1);
	fa[tn]=-1,sz[tn]=0;
	return tn++;
}
int rt=newsam(),t=rt;
void insert(int c){
	int p=t,np=t=newsam();
	len[np]=len[p]+1;
	for(;~p&&!~ch[p][c];p=fa[p]) ch[p][c]=np;
	if(!~p) fa[np]=rt;
	else {
		int q=ch[p][c];
		if(len[q]==len[p]+1) fa[np]=q;
		else {
			int nq=newsam();
			copy(ch[q],ch[q]+26,ch[nq]);
			len[nq]=len[p]+1,fa[nq]=fa[q],fa[q]=fa[np]=nq;
			for(;~p&&ch[p][c]==q;p=fa[p]) ch[p][c]=nq;
		}
	}
	sz[np]=1;
}
int cnt[N+1],q[tN];
void buildsam(){
	R(i,0,tn) cnt[len[i]]++;
	R(i,1,n+1) cnt[i]+=cnt[i-1];
	R(i,0,tn) q[--cnt[len[i]]]=i;
	L(i,0,tn)if(i!=rt) sz[fa[q[i]]]+=sz[q[i]];
	sz[rt]=0;
}
bool vis[tN];

//Main
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>s,n=sz(s);
	R(i,0,n) insert(s[i]-'a');
	buildsam();
	cin>>qn;
	R(ta,0,qn){
		cin>>s,n=sz(s);
		int p=rt,now=0; ll ans=0;
		vector<int> used;
		R(i,0,n*2-1){
			int c=s[i%n]-'a';
			if(~ch[p][c]) now++,p=ch[p][c];
			else {
				for(;~p&&!~ch[p][c];p=fa[p]);
				if(!~p) now=0,p=rt;
				else now=len[p]+1,p=ch[p][c];
			}
			if(now==n){
				if(!vis[p]) ans+=sz[p],vis[p]=true,used.pb(p);
				if(len[fa[p]]+1==now) p=fa[p];
				now--;
			}
		}
		for(int q:used) vis[q]=false;
		cout<<ans<<'\n';
	}
	return 0;
}
