#include <iostream>
#include <algorithm>
int sum(int*,int,int);
using namespace std;
int n,k,m,b=0;
int ma[100100];
int ba[100100];

int main(){
    cin >> n >>k;
    m=sum(ma,n,k);
    b=sum(ba,n,k);
    if(m>b){
        cout<<"MAHMOUD"<<'\n';
    }else if(m<b){
        cout<<"BASHAR"<<'\n';
    }else{
        cout<<"DRAW"<<'\n';
    }
    return 0;
}

int sum(int* m,int n,int k){
    for(int i=0;i<n;i++) {
        cin >> m[i];
    }
    sort (m,m+n);
    int a=0;
    for(int i=0;i<n&&m[i]<k;i++){
        for(int j=i+1;j<n&&m[j]<k;j++){
            if(m[i]+m[j]==k){
                a++;
            }
        }
    }
    return a;
}