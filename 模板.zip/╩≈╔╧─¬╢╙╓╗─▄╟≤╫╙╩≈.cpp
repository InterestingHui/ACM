#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define fa(i,V) for(auto i:V)
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
using namespace std;
const int INF=LLONG_MAX-1e10;
const int maxn=1e6+5;
const int mo_num=1e9+7;
int n,m,a[maxn],b[maxn],ans;
vct edge[maxn];
int Time,Start[maxn],End[maxn],vis[maxn],f[maxn],belong[maxn],Ans[maxn],cnk[maxn],cnt[maxn];

//注意！这个dfs完成的不是任意两点的路径，而是只能完成由某点跑完所有其子树的路径
void dfs(int to)
{
    Start[to]=++Time;
    f[Time]=a[to];
    vis[to]=1;
    fa(i,edge[to])
    {
        if(!vis[i])dfs(i);
    }
    End[to]=Time;
}
struct node{
    int l,r,k,id;
}have[maxn];
void add(int pos)
{
    cnt[f[pos]]++;
    cnk[cnt[f[pos]]]++;
}
void del(int pos)
{
    cnk[cnt[f[pos]]]--;
    cnt[f[pos]]--;
}
int cmp(node a,node b)
{
    return belong[a.l]==belong[b.l]?a.r<b.r:belong[a.l]<belong[b.l];
}
main()
{
    IOS
    cin>>n>>m;
    int len=ceil(sqrt(n));int block=len;
    fun(i)belong[i]=(i-1)/block+1;
    fun(i)
    {
        cin>>a[i];
    }
    fu(i,1,n-1)
    {
        int u,v;
        cin>>u>>v;
        edge[u].pb(v);
        edge[v].pb(u);
    }
    dfs(1);

    fum(i)
    {
        int vv,kk;
        cin>>vv>>kk;
        //注意，该题只适用于一下的路径链化方法，是特殊的！
        // 即只能是Start[vv]->End[vv]代表走完vv这个点的所有子树（包括它自己）
        have[i]={Start[vv],End[vv],kk,i};
    }
    sort(im(have),cmp);
    int l=have[1].l,r=have[1].l-1;
    fum(i)
    {
        while(l < have[i].l) del(l++);
        while(l > have[i].l) add(--l);
        while(r < have[i].r) add(++r);
        while(r > have[i].r) del(r--);
        Ans[have[i].id]=cnk[have[i].k];
    }
    fum(i)out(Ans[i])
    return 0;
}
