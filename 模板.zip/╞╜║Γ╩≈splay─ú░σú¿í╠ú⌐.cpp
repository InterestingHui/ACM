#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int INF=LLONG_MAX-1e10;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e5+10;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;

class Splay//�洢����С����ң��ظ��ڵ��¼
{
#define root e[0].ch[1]   //�����ĸ��ڵ�
private:
    class node
    {
    public:
        int v,father;//�ڵ�ֵ�������ڵ�
        int ch[2];//����=0���Һ���=1
        int sum;//�Լ�+�Լ��¼��ж��ٽڵ㡣�ڸ��ڵ�Ϊ1��
        int recy;//��¼�Լ����ظ��˼���
    };
    node e[maxn];//Splay������
    int n,points;//ʹ�ô洢��,Ԫ����
    void update(int x)
    {
        e[x].sum=e[e[x].ch[0]].sum+e[e[x].ch[1]].sum+e[x].recy;
    }
    int identify(int x)
    {
        return e[e[x].father].ch[0]==x?0:1;
    }
    void connect(int x,int f,int son)//���Ӻ������÷���connect(son,father,1/0)
    {
        e[x].father=f;
        e[f].ch[son]=x;
    }//���ã�ʹ��x��father=f��f��son=x.
    void rotate(int x)
    {
        int y=e[x].father;
        int mroot=e[y].father;
        int mrootson=identify(y);
        int yson=identify(x);
        int B=e[x].ch[yson^1];
        connect(B,y,yson);connect(y,x,(yson^1));connect(x,mroot,mrootson);
        update(y);update(x);
    }
    void splay(int at,int to)//��atλ�õĽڵ��ƶ���toλ��
    {
        to=e[to].father;
        while(e[at].father!=to)
        {
            int up=e[at].father;
            if(e[up].father==to) rotate(at);
            else if(identify(up)==identify(at))
            {
                rotate(up);
                rotate(at);
            }
            else
            {
                rotate(at);
                rotate(at);
            }
        }
    }
    int crepoint(int v,int father)
    {
        n++;
        e[n].v=v;
        e[n].father=father;
        e[n].sum=e[n].recy=1;
        return n;
    }
    void destroy(int x)//pop��ݻٽڵ�
    {
        e[x].v=e[x].ch[0]=e[x].ch[1]=e[x].sum=e[x].father=e[x].recy=0;
        if(x==n) n--;//����޶��Ż�
    }
public:
    int getroot(){return root;}
    int find(int v)//�����ⲿ��find����
    {
        int now=root;
        while(true)
        {
            if(e[now].v==v)
            {
                splay(now,root);
                return now;
            }
            int next=v<e[now].v?0:1;
            if(!e[now].ch[next]) return 0;
            now=e[now].ch[next];
        }
    }
    int build(int v)//�ڲ����õĲ��뺯����û��splay
    {
        points++;
        if(points==1)//�����޵�״̬
        {
            root = n + 1;
            crepoint(v, 0);
        }
        else
        {
            int now=root;
            while(true)//�����ҵ�һ���սڵ�
            {
                e[now].sum++;//�Լ����¼��϶�������һ���ڵ�
                if(v==e[now].v)
                {
                    e[now].recy++;
                    splay(now,root);
                    return now;
                }
                int next=v<e[now].v?0:1;
                if(!e[now].ch[next])
                {
                    crepoint(v,now);
                    e[now].ch[next]=n;
                    splay(now,root);
                    return n;
                }
                now=e[now].ch[next];
            }
        }

        return 0;
    }
    void push(int v)//����Ԫ��ʱ�������ӽڵ㣬�ٽ�����չ
    {
        int add=build(v);
        splay(add,root);
    }
    void pop(int v)//ɾ���ڵ�
    {
        int deal=find(v);
        if(!deal) return;
        points--;
        if(e[deal].recy>1)
        {
            e[deal].recy--;
            e[deal].sum--;
            return;
        }
        if(!e[deal].ch[0])
        {
            root=e[deal].ch[1];
            e[root].father=0;
        }
        else
        {
            int lef=e[deal].ch[0];
            while(e[lef].ch[1]) lef=e[lef].ch[1];
            splay(lef,e[deal].ch[0]);
            int rig=e[deal].ch[1];
            connect(rig,lef,1);connect(lef,0,1);
            update(lef);
        }
        destroy(deal);
    }
    int rank(int v)//��ȡֵΪv��Ԫ������������ǵڼ�С
    {
        int ans=0,now=root;
        while(true)
        {
            if(e[now].v==v) {
                int ANS=ans + e[e[now].ch[0]].sum + 1;
                splay(now,root);
                return ANS;
            }
            if(now==0) return 0;
            if(v<e[now].v) now=e[now].ch[0];
            else
            {
                ans=ans+e[e[now].ch[0]].sum+e[now].recy;
                now=e[now].ch[1];
            }
        }
    }
    int atrank(int x)//��ȡ��xС��Ԫ�ص�ֵ
    {
        if(x>points) return -INF;
        int now=root;
        while(true)
        {
            int minused=e[now].sum-e[e[now].ch[1]].sum;
            if(x>e[e[now].ch[0]].sum&&x<=minused) break;
            if(x<minused) now=e[now].ch[0];
            else
            {
                x=x-minused;
                now=e[now].ch[1];
            }
        }
        splay(now,root);
        return e[now].v;
    }
    int upper(int v)//Ѱ�Ҹ�ֵ��Ӧ��һ��������Ͻ�ֵ
    {
        int now=root;
        int result=INF;
        while(now)
        {
            if(e[now].v>v&&e[now].v<result) result=e[now].v;
            if(v<e[now].v) now=e[now].ch[0];
            else now=e[now].ch[1];
        }
        return result;
    }
    int lower(int v)//Ѱ�Ҹ�ֵ��Ӧ��һ��������½�ֵ
    {
        int now=root;
        int result=-INF;
        while(now)
        {
            if(e[now].v<v&&e[now].v>result) result=e[now].v;
            if(v>e[now].v) now=e[now].ch[1];
            else now=e[now].ch[0];
        }

        return result;
    }
#undef root
};
Splay F;

main()
{
    IOS
    cin>>n;
    fun(i)
    {
        cin>>a[1]>>a[2];
        if(a[1]==1)
        {
            F.build(a[2]);
        }else if(a[1]==2)
        {
            F.pop(a[2]);
        }else if(a[1]==3)
        {
            out(F.rank(a[2]))
        }else if(a[1]==4)
        {
            out(F.atrank(a[2]))
        }else if(a[1]==5)
        {
            out(F.lower(a[2]))
        }else out(F.upper(a[2]))
    }
    return 0;
}
