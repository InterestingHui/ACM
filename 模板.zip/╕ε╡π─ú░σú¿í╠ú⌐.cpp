/*
 * 问题描述:
    给出一个 n 个点，m 条边的无向图，求图的割点。
输入格式:
    第一行输出割点个数。
    第二行按照节点编号从小到大输出节点，用空格隔开。
输出格式：
    第一行输出割点个数。
    第二行按照节点编号从小到大输出节点，用空格隔开。
Input1:
    6 7
    1 2
    1 3
    1 4
    2 5
    3 5
    4 5
    5 6
Output1:
    1
    5
 */
struct edge{
    int to,val,next;
}e[maxn];
int cnt,head[maxn<<1];
void add(int x,int y,int c){
    e[cnt]={y,c,head[x]};//这一行实现了简洁！
    head[x]=cnt++;
}
int dfn[maxn],Low[maxn],Time,child,cut[maxn];
void tarjan(int now,int Begin)
{
    if(now==Begin)child=0;
    Low[now]=dfn[now]=++Time;
    fh(i,now,e)
    {
        int to=e[i].to;
        if(!dfn[to])
        {
            tarjan(to,Begin);
            Low[now]=min(Low[now],Low[to]);
            if(now==Begin)child++;
            else if(Low[to]>=dfn[now])cut[now]=1;
        }else Low[now]=min(Low[now],dfn[to]);
    }
    if(child>=2 && now==Begin)cut[Begin]=1;
}
main()
{
    IOS
    memset(head,-1,sizeof(head));
    cin>>n>>m;
    fum(i)
    {
        int u,v;
        cin>>u>>v;
        add(u,v,1);
        add(v,u,1);
    }
    fun(i)if(!dfn[i])tarjan(i,i);
    fun(i)ans+=cut[i]?1:0;
    out(ans)
    fun(i)if(cut[i])cout<<i<<" ";
    return 0;
}
