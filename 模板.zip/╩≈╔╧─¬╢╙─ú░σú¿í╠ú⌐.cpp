#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int INF=LLONG_MAX-1e10;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=2e5+5;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
int Start[maxn],End[maxn],dfn[maxn],fa[maxn],num,Size[maxn];
int f[maxn],dep[maxn],son[maxn],top[maxn],cnt[maxn],now,block,l=1,r,use[maxn],Ans[maxn],data[maxn],belong[maxn];
//f[]数组存储的是将树 链化后的序列，所以一个游标如l，右移，则考虑的数是a[f[++l]];
vct edge[maxn];
struct query{
    int l,r,id,lca,ll,rr;
}have[maxn];
void dfs1(int u,int from)  //树剖第一次深搜
{
    fa[u]=from;Start[u]=++num;
    Size[u]=1;f[num]=u;
    dep[u]=dep[from]+1;
    fa(i,edge[u])
    {
        if (i==from)continue;
        dfs1(i,u);
        Size[u]+=Size[i];
        if (Size[i]>Size[son[u]])son[u]=i;
    }
    End[u]=++num;f[num]=u;
}
void dfs2(int u,int to)   //树剖第二次深搜
{
    top[u]=to;
    if (son[u])dfs2(son[u],to);
    fa(i,edge[u])
    {
        if (i!=son[u]&&i!=fa[u])dfs2(i,i);
    }
}
int Lca(int x,int y)   //树剖求lca
{
    while (top[x]!=top[y])
    {
        if (dep[top[x]]<dep[top[y]])swap(x,y);
        x=fa[top[x]];
    }
    if (dep[x]>dep[y])swap(x,y);
    return x;
}
void add(int x)
{
    now+=!cnt[a[x]]++;
}
void del(int x)
{
    now-=!--cnt[a[x]];
}
void calc(int x)     //对点进行加入或删除
{
    (!use[x])?add(x):del(x);
    use[x]^=1;
}
int cmp(query x,query y)   //排序
{
    return (x.ll==y.ll)?(x.ll%2==1?x.r<y.r:x.r>y.r):x.l<y.l;
}
main()
{
    cin>>n>>m;
    for (int i=1;i<=n;i++)cin>>a[i],data[i]=a[i];
    sort(data+1,data+n+1);for(int i=1;i<=n;i++)a[i]=lower_bound(data+1,data+n+1,a[i])-data;  //离散化
    for (int i=1;i<n;i++)
    {
        int x,y;
        cin>>x>>y;
        edge[x].pb(y);
        edge[y].pb(x);
    }
    dfs1(1,0);
    dfs2(1,1);
    block=n*2/sqrt(m*2/3);
    for (int i=1;i<=m;i++)
    {
        int x,y;
        cin>>x>>y;
        if (Start[x]>Start[y])swap(x,y);  //保证stx<sty
        have[i].id=i;
        have[i].lca=Lca(x,y);
        if (have[i].lca==x)    //x,y在以x为根的子树中
        {
            have[i].l=Start[x];
            have[i].r=Start[y];
            have[i].ll=Start[x]/block;
            have[i].rr=Start[y]/block;
            have[i].lca=0;
        } else
        {
            have[i].l=End[x];
            have[i].r=Start[y];
            have[i].ll=End[x]/block;
            have[i].rr=Start[y]/block;
        }
    }
    sort(im(have),cmp);
    fum(i)
    {
        //注意！树上莫队只能是calc，不能直接明确是add还是del，以为你两次代表不计算（即路径上无该点）
        while (l>have[i].l)calc(f[--l]);
        while (r<have[i].r)calc(f[++r]);
        while (l<have[i].l)calc(f[l++]);
        while (r>have[i].r)calc(f[r--]);
        if (have[i].lca)calc(have[i].lca);
        Ans[have[i].id]=now;
        if (have[i].lca)calc(have[i].lca);
    }
    fum(i)out(Ans[i])
    return 0;
}