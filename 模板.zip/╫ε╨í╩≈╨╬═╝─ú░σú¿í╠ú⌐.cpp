#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
//#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
#define int long long
#define got(container,num) get<num-1>(container)
using namespace std;
const int INF=INT_MAX;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e4+10;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
struct edge{
    int from,to,val,next;//from
}e[maxn];
int cnt,head[maxn<<1];
void add(int x,int y,int c){
    e[cnt]={x,y,c,head[x]};//��һ��ʵ���˼�࣡
    head[x]=cnt++;
}
int vis[maxn],id[maxn],pre[maxn],Min[maxn],num;
bool zhuliu(int root)
{
    while(1)
    {
        fun(i)id[i]=0,Min[i]=INF,vis[i]=0;
        num=0;
        fu(i,0,cnt-1) {
            int u = e[i].from, v = e[i].to, val = e[i].val;
            if (u != v && val < Min[v]) {
                Min[v] = val;
                pre[v] = u;
            }
        }
        Min[root]=0;
        int u;
        fun(i)
        {
            if(Min[i]==INF)return 0;
            ans+=Min[i];
            for(u=i;vis[u]!=i && !id[u] && u!=root;u=pre[u])vis[u]=i;
            if(u!=root && !id[u])
            {
                id[u]=++num;
                for(int v=pre[u];v!=u;v=pre[v])id[v]=num;
            }
        }

        if(!num)return 1;
        fun(i)if(!id[i])id[i]=++num;
        fu(i,0,cnt-1)
        {
            int gget=Min[e[i].to];
            if((e[i].from=id[e[i].from])!=(e[i].to=id[e[i].to]))e[i].val-=gget;
        }
        n=num;
        root=id[root];
    }
}
main()
{
    IOS
    memset(head,-1,sizeof(head));
    int root;
    cin>>n>>m>>root;
    fum(i)
    {
        int u,v,w;
        cin>>u>>v>>w;
        add(u,v,w);
    }
    out(zhuliu(root)?ans:-1)
    return 0;
}


