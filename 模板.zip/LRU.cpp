#include<bits/stdc++.h>
using namespace std;
class LRUcache{
private:
    struct linkedlist{
        int key,val;
        linkedlist *prev,*next;
        linkedlist():key(0),val(0),prev(nullptr),next(nullptr){}
        linkedlist(int _key,int _val):key(_key),val(_val),prev(nullptr),next(nullptr){}
    };
    unordered_map<int,linkedlist*>hash;
    int size,capacity;
    linkedlist *head,*tail;
public:
    LRUcache(int _capacity):capacity(_capacity),size(0){
        head = new linkedlist();
        tail = new linkedlist();
        head->next=tail;
        tail->prev=head;
    }
    void remove(linkedlist *node)
    {
        node->prev->next=node->next;
        node->next->prev=node->prev;
        delete node;
    }
    void addTohead(linkedlist *node)
    {
        hash[node->key]=node;
        head->next->prev=node;
        node->next=head->next->prev;
        head->next=node;
        node->prev=head;
    }
    void Add(int key,int val)
    {
        if(size==capacity)
        {
            size--;
            hash.erase(tail->prev->key);
            remove(tail->prev);
        }
        size++;
        linkedlist *node = new linkedlist(key,val);
        addTohead(node);
    }
    void Update(int key,int val)
    {
        if(hash[key]==nullptr){
            Add(key,val);
        }else{
            linkedlist *node = hash[key];
            hash.erase(key);
            remove(node);
            Add(key,val);
        }
    }
    void Delete(int key)
    {
        if(hash[key]==nullptr)return ;
        linkedlist *node = hash[key];
        hash.erase(key);
        remove(node);
        size--;
    }
    int Get(int key)
    {
        if(hash[key]==nullptr)return -1;
        linkedlist *node = hash[key];
        int ans=node->val;
        remove(node);
        size--;
        Add(key,ans);
        return ans;
    }
};
int main()
{
    LRUcache lRUCache(2);
    lRUCache.Update(1, 1);
    lRUCache.Update(2, 2);
    cout<<lRUCache.Get(1)<<endl;//1
    lRUCache.Delete(1);
    lRUCache.Update(3, 3);
    cout<<lRUCache.Get(2)<<endl;//2
    lRUCache.Update(4, 4);
    cout<<lRUCache.Get(1)<<endl;//-1
    cout<<lRUCache.Get(3)<<endl;//-1
    cout<<lRUCache.Get(4)<<endl;//4
    return 0;
}
