#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int INF=LLONG_MAX-1e10;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e5+10;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
struct edge{
    int to,val,next;
}e[maxn<<1];
//���ڲ�����map��������maxm 2e7������,С�ı��ռ�
const int maxm=2e7+1;
int cnt,head[maxn],have[maxm],query[maxn],rt,son[maxn],Ans[maxn],sz[maxn],vis[maxn],sum,dis[maxn],f[maxn],Past[maxn];
void add(int x,int y,int c){
    e[cnt]={y,c,head[x]};//��һ��ʵ���˼�࣡
    head[x]=cnt++;
}

void getrt(int now,int from)
{
    sz[now]=1;
    son[now]=0;
    fh(i,now,e)
    {
        int v=e[i].to;
        if(vis[v] or v==from)continue;
        getrt(v,now);
        sz[now]+=sz[v];
        son[now]=max(son[now],sz[v]);
    }
    son[now]=max(son[now],sum-sz[now]);
    if(son[now]<son[rt])rt=now;
}
void getdis(int now,int from)
{
    f[++f[0]]=dis[now];
    fh(i,now,e)
    {
        int v=e[i].to;
        if(vis[v] or v==from)continue;
        dis[v]=dis[now]+e[i].val;
        getdis(v,now);
    }
}
void cal(int now)
{
    int q=0;
    fh(ii,now,e)
    {
        int v=e[ii].to;
        if(vis[v])continue;
        f[0]=0;
        dis[v]=e[ii].val;
        getdis(v,now);
        fu(i,1,f[0])fum(j)if(f[i]<=query[j])Ans[j]|=have[query[j]-f[i]];
        fu(i,1,f[0])Past[++q]=f[i],have[f[i]]=1;
    }
    fu(i,1,q)have[Past[i]]=0;
}
void solve(int now)
{
    vis[now]=1;
    cal(now);
    fh(i,now,e)
    {
        int v=e[i].to;
        if(vis[v])continue;
        sum=sz[v];
        son[rt=0]=INF;
        getrt(v,0);
        solve(rt);
    }
}
main()
{
    IOS
    cin>>n>>m;
    memset(head,-1,sizeof(head));
    fu(i,1,n-1)
    {
        int u,v,l;
        cin>>u>>v>>l;
        add(u,v,l);
        add(v,u,l);
    }
    fum(i)cin>>query[i];
    have[0]=1;
    sum=son[rt]=n;
    getrt(1,0);
    solve(rt);
    fum(i)out(Ans[i]?"AYE":"NAY")
    return 0;
}