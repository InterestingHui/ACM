#define fh(i,head,be,e) for(int i=head[be];~i;i=e[i].next)

struct node{
    int to,val,next;
}e[maxn];
int cnt,head[maxn<<1],cur[maxn];
void add(int x,int y,int c)
{
    e[cnt]={y,c,head[x]},head[x]=cnt++;
}
int dis[maxn];
bool bfs(int s)
{
    mst(dis,-1);
    dis[s]=0;
    queue<int>Que;
    Que.push(s);
    while(!Que.empty())
    {
        int now=Que.front();
        Que.pop();
        fh(i,head,now,e)
        {
            int to=e[i].to;
            if(dis[to]==-1 && e[i].val)
            {
                dis[to]=dis[now]+1;
                Que.push(to);
            }
        }
    }
    return ~dis[t];
}
int dinic(int now,int flow)
{
    int be=flow;
    if(now==t)return flow;
    fh(i,cur,now,e)
    {
        cur[now]=i;
        int to=e[i].to;
        if(dis[to]==dis[now]+1 && e[i].val)
        {
            int gget=dinic(to,min(be,e[i].val));
            be-=gget;
            e[i].val-=gget;
            e[i^1].val+=gget;
            if(!be)break;
        }
    }
    return flow-be;
}
void solve()
{
    int s;
    mst(head,-1);
    cin>>n>>m>>s>>t;
    fum(i)
    {
        int u,v,w;
        cin>>u>>v>>w;
        add(u,v,w);
        add(v,u,0);
    }
    while(bfs(s))
    {
        fun(i)cur[i]=head[i];
        ans+=dinic(s,INF);
    }
    out(ans)
    return ;
}