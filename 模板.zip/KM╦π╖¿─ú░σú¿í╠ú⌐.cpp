#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
#define got(container,num) get<num-1>(container)
using namespace std;
const int INF=LLONG_MAX/2;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e6+1e5;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
const int N=305;
int w[N][N],lx[N],ly[N],link[N],slack[N],visx[N],visy[N];
int Find(int x)
{
    visx[x]=1;
    fun(i)
    {
        if(visy[i])continue;
        int t=lx[x]+ly[i]-w[x][i];
        if(!t)
        {
            visy[i]=1;
            if(!link[i] or Find(link[i])) {
                link[i]=x;
                return 1;
            }
        }else slack[i]=min(slack[i],t);
    }
    return 0;
}
int km()
{
    fun(i)lx[i]=ly[i]=link[i]=0;
    fun(i)
        fun(j)
            lx[i]=max(lx[i],w[i][j]);
    fun(i)
    {
        while(1)
        {
            fun(j)slack[j]=INF,visx[j]=visy[j]=0;
            if(Find(i))break;
            int Min=INF;
            fun(j)Min=min(Min,slack[j]);
            fun(j)
            {
                lx[j]-=(visx[j]?Min:0);
                ly[j]+=(visy[j]?Min:0);
            }
        }
    }
    int num=0;
    fun(i)num+=w[link[i]][i];
    return num;
}
main()
{
    IOS
    while(cin>>n) {
        fun(i)fun(j)cin >> w[i][j];
        out(km())
    }
    return 0;
}
