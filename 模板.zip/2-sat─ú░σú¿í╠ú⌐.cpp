/*
问题描述:
有n个布尔变量x[1]~x[n]，另有m个需要满足的条件，每个条件的形式都[x[i]为 true/false 或 x[j]为 true/false]。
比如「x[1]为真 或 x[2]为假」、「x[7]为假 或 x[2]为假」。
2-SAT问题的目标是给每个变量赋值使得所有条件得到满足。
输入格式:
    第一行两个整数n、m
    下面m行每行给出四个整数i,a,j,b，表示该行条件为[x[i]=a or x[j]=b] (0<=a,b<=1)
输出格式
    如无解，输出 IMPOSSIBLE;
    否则输出 POSSIBLE,下一行n个整数表示构造出的解，第i个数表示x[i]的值
INPUT:
    3 1
    1 1 3 0
OUTPUT:
    POSSIBLE
    0 0 0
 * */
int n,m,t,a[maxn],b[maxn],ans,case_of_T;
struct{ int to,val,next; }e[maxn<<1];
int cnt,head[maxn<<1];
int dfn[maxn],Low[maxn],vis[maxn],TIME,Time,Stack[maxn],sd[maxn];
void add(int x,int y,int c) { e[cnt]={y,c,head[x]},head[x]=cnt++; }
void tarjan(int now)
{
    Low[now]=dfn[now]=Time++;
    Stack[Time-1]=now,vis[now]=1;
    fh(i,now,e)
    {
        int to=e[i].to;
        if(!dfn[to])
        {
            tarjan(to);
            Low[now]=min(Low[now],Low[to]);
        }else if(vis[to])Low[now]=min(Low[now],dfn[to]);
    }
    if(dfn[now]==Low[now])
    {
        int y;
        TIME++;
        while(y=Stack[--Time])
        {
            sd[y]=TIME;
            vis[y]=0;
            if(y==now)break;
        }
    }
}
void solve()
{
    mst(head,-1);
    cin>>n>>m;
    fum(i)
    {
        fu(j,1,4)cin>>a[j];
        add(a[1]+n*a[2],a[3]+n*(a[4]^1),1);
        add(a[3]+n*a[4],a[1]+n*(a[2]^1),1);
    }
    fu(i,1,2*n)if(!dfn[i])tarjan(i);
    fun(i)if(sd[i]==sd[i+n]){out("IMPOSSIBLE")return;}
    out("POSSIBLE")
    fun(i)cout<<(sd[i]<sd[i+n])<<" ";
    return ;
}