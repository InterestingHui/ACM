/*
 * 问题描述:
    给定一个矩阵n行m列(1<=n,m<=500)，有q(0<=q<=n*m)次操作，每次点亮矩阵中的某个位置
    问矩阵中第一次出现k×k(1<=k<=min(n,m))子矩阵全被点亮的时间或说明没有满足条件的时刻
输入格式:
    第一行四个整数n、m、k、q代表矩阵的行数、列数、目标正方子矩阵边长、操作次数
    下面给出q行，每行三个整数x、y、t代表在t时刻第x行第y列的数被点亮
输出格式：
    输出一个整数代表最早出现k×k矩阵全被点亮的时刻，q次操作后仍为出现，则输出-1
Input1:
    2 3 2 5
    2 1 8
    2 2 8
    1 2 1
    1 3 4
    2 3 2
Output1:
    8
思路：
    二维线段树每个位置都初始化为INF
    q次操作每次都视为二维线段树的单点修改，记录其最早时间，然后最后对每个可能子矩阵求最大数
*/
//https://codeforces.com/problemset/problem/846/D
#include<bits/stdc++.h>
#define ls rt<<1
#define rs rt<<1|1
#define lson rt<<1,l,M
#define rson rt<<1|1,M+1,r
#define PI acos(-1)
#define MM int M=(l+r)>>1;
#define fu(i,r,t) for(int i=r;i<=t;i++)
#define fd(i,r,t) for(int i=r;i>=t;i--)
#define fh(i,be,e) for(int i=head[be];~i;i=e[i].next)
#define fa(i,V) for(auto i:V)
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define endl '\n'
#define lcm(a,b) (a*b)/__gcd(a,b)
#define cp(i,ans) printf("%.if",ans);
#define cpp(i,ans) cout<<setprecision(i)<<fixed<<ans<<endl;
#define ppb pop_back
#define ppf pop_front
#define pb push_back
#define pf push_front
#define pq priority_queue
#define lowbit(x) (x)&(-x)
#define all(V) V.begin(),V.end()
#define ms multiset
#define mod(x) ((x+mo_num)%mo_num)
#define vc vector
#define vct vector<int>
#define out(i) cout<<(i)<<endl;
#define fi first
#define se second
#define fun(i) fu(i,1,n)
#define fut(i) fu(i,1,t)
#define fum(i) fu(i,1,m)
#define ld long double
#define umap unordered_map
#define P pair<int,int>
#define SET set<int>
#define mp map<int,int>
#define mk make_tuple
#define low lower_bound
#define upp upper_bound
#define yn(key) out(key?"YES":"NO")
#define in(i) i+1,i+1+n
#define im(i) i+1,i+1+m
#define bffs(i) __builtin_ffs(i)
#define bcount(i) __builtin_popcount(i)
#define bone(i) ((1<<i)-1)
using namespace std;
const int INF=LLONG_MAX-1e10;
const int dx[]={0,0,-1,1},dy[]={-1,1,0,0};//up down left right
const int maxn=1e6+1e5;
const int mo_num=1e9+7;
int n,m,t,a[maxn],b[maxn],ans;
const int N=505;
int st[N<<3][N<<3];
void build_in(int zrt,int rt,int l,int r)
{
    if(l==r)
    {
        st[zrt][rt]=INF;
        return;
    }
    MM;
    build_in(zrt,lson);
    build_in(zrt,rson);
    st[zrt][rt]=INF;
}
void build_out(int rt,int l,int r)
{
    if(l==r)
    {
        build_in(rt,1,1,m);
        return ;
    }
    MM;
    build_out(lson);
    build_out(rson);
    build_in(rt,1,1,m);
}
void update_in(int zrt,int rt,int l,int r,int y,int val,int kind)
{
    if(l==r)
    {
        if(kind)
        {
            st[zrt][rt]=val;
        }else{
            st[zrt][rt]=max(st[zrt<<1][rt],st[zrt<<1|1][rt]);
        }
        return;
    }
    MM;
    if(M>=y)update_in(zrt,lson,y,val,kind);
    else update_in(zrt,rson,y,val,kind);
    st[zrt][rt]=max(st[zrt][ls],st[zrt][rs]);
}
void update_out(int rt,int l,int r,int x,int y,int val)
{
    if(l==r)
    {
        update_in(rt,1,1,m,y,val,1);
        return;
    }
    MM;
    if(M>=x)update_out(lson,x,y,val);
    else update_out(rson,x,y,val);
    update_in(rt,1,1,m,y,val,0);
}
int query_in(int zrt,int rt,int l,int r,int zy,int yy)
{
    if(zy<=l && r<=yy)
    {
        return st[zrt][rt];
    }
    MM;
    int num=0;
    if(M>=zy)num=query_in(zrt,lson,zy,yy);
    if(M<yy)num=max(num,query_in(zrt,rson,zy,yy));
    return num;
}
int query_out(int rt,int l,int r,int zx,int zy,int yx,int yy)
{
    if(zx<=l && r<=yx)
    {
        return query_in(rt,1,1,m,zy,yy);
    }
    MM;
    int num=0;
    if(M>=zx)num=query_out(lson,zx,zy,yx,yy);
    if(M<yx)num=max(num,query_out(rson,zx,zy,yx,yy));
    return num;
}
main()
{
    IOS
    int k,q;
    cin>>n>>m>>k>>q;
    build_out(1,1,n);
    ans=INF;
    fu(i,1,q)
    {
        int x,y,time;
        cin>>x>>y>>time;
        update_out(1,1,n,x,y,time);
    }
    fu(i,1,n-k+1)
    {
        fu(j,1,m-k+1)
        {
            ans=min(ans,query_out(1,1,n,i,j,i+k-1,j+k-1));
        }
    }
    out(ans==INF?-1:ans)
    return 0;
}
